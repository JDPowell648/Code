package blackjack;

import java.util.ArrayList;

public class Game {
    private ArrayList<Player> players;
    private Shoe shoe;

    public Game( int numDecks )
    {
        shoe = new Shoe( 6 );
    }

    public void addPlayer ( Player p )
    {
        players.add( p );
    }

    public ArrayList<Player> getPlayers()
    {
        return players;
    }
}
