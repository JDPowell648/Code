package blackjack;

public class Card {
}
